#ifndef EIGEN_QR_MODULE_H
#error "Please include Eigen/QR instead of including headers inside the src directory directly."
#endif
