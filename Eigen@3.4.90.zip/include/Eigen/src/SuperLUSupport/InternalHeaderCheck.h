#ifndef EIGEN_SUPERLUSUPPORT_MODULE_H
#error "Please include Eigen/SuperLUSupport instead of including headers inside the src directory directly."
#endif
